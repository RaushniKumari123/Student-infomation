
import java.util.ArrayList;
import java.util.Scanner;

public class main {

    // ANSI color codes for light backgrounds and text
    public static final String RESET = "\u001B[0m";
    public static final String LIGHT_PINK_BG = "\u001B[48;5;218m"; 
    public static final String LIGHT_BLUE_BG = "\u001B[48;5;33m";  
    public static final String BLACK_TEXT = "\u001B[30m";  
    public static final String CYAN_TEXT = "\u001B[36m";  
    public static final String YELLOW_TEXT = "\u001B[33m"; 
    public static final String WHITE_TEXT = "\u001B[37m";  // White Text

    public static void displayHeader() {
        System.out.println(LIGHT_PINK_BG + BLACK_TEXT);
        System.out.println("╔══════════════════════════════════════════════════════╗");
        System.out.println("║               STUDENT INFORMATION SYSTEM             ║");
        System.out.println("║                   Mini Project - Java                ║");
        System.out.println("║------------------------------------------------------║");
        System.out.println("║  Features:                                           ║");
        System.out.println("║   - OOP Principles                                   ║");
        System.out.println("║   - Inheritance & Overloading                        ║");
        System.out.println("║   - Interface & Static Members                       ║");
        System.out.println("║   - Student, Graduate Student & Course Classes       ║");
        System.out.println("╚══════════════════════════════════════════════════════╝\n");
        System.out.print(RESET);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Student> students = new ArrayList<>();

        displayHeader();

        while (true) {
            System.out.print(CYAN_TEXT + "\nEnter name: " + RESET);
            String name = sc.nextLine();

            System.out.print(CYAN_TEXT + "Enter age: " + RESET);
            int age = sc.nextInt();
            sc.nextLine(); // clear buffer

            System.out.print(CYAN_TEXT + "Enter student ID: " + RESET);
            String id = sc.nextLine();

            System.out.print(CYAN_TEXT + "Enter course name: " + RESET);
            String courseName = sc.nextLine();

            System.out.print(CYAN_TEXT + "Enter course credits: " + RESET);
            int credits = sc.nextInt();

            System.out.print(CYAN_TEXT + "Enter marks: " + RESET);
            double marks = sc.nextDouble();
            sc.nextLine(); // clear buffer

            System.out.print(CYAN_TEXT + "Are you a graduate student? (yes/no): " + RESET);
            String gradAnswer = sc.nextLine();

            Course course = new Course(courseName, credits);

            if (gradAnswer.equalsIgnoreCase("yes")) {
                System.out.print(CYAN_TEXT + "Enter thesis topic: " + RESET);
                String thesis = sc.nextLine();
                students.add(new GraduateStudent(name, age, id, course, marks, thesis));
            } else {
                Student.add(new Student(name, age, id, course, marks));
            }

            System.out.print(YELLOW_TEXT + "Add another student? (yes/no): " + RESET);
            String more = sc.nextLine();
            if (more.equalsIgnoreCase("no")) break;
        }

        System.out.println(LIGHT_BLUE_BG + WHITE_TEXT + "\n======= STUDENT DETAILS =======" + RESET);
        for (Student s : students) {
            System.out.println("───────────────────────────────");
            s.displayStudent();
        }

        System.out.println("\nTotal Students Registered: " + Student.getStudentCount());
        sc.close();
    }
}
