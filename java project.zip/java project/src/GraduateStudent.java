public class GraduateStudent extends Student {
    private String thesisTopic;

    public GraduateStudent(String name, int age, String studentId, Course course, double marks, String thesisTopic) {
        super(name, age, studentId, course, marks);
        this.thesisTopic = thesisTopic;
    }

    @Override
    public void displayStudent() {
        super.displayStudent();
        System.out.println("Thesis Topic: " + thesisTopic);
    }
}

