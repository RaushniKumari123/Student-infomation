
public class Student extends Person implements Grading {
    private String studentId;
    private Course course;
    private double marks;
    private static int studentCount = 0;

    public Student(String name, int age, String studentId, Course course, double marks) {
        super(name, age);
        this.studentId = studentId;
        this.course = course;
        this.marks = marks;
        studentCount++;
    }

    public static int getStudentCount() {
        return studentCount;
    }

    public void displayStudent() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Student ID: " + studentId);
        System.out.println("Course: " + course.getCourseName() + " (" + course.getCredits() + " credits)");
        System.out.println("Marks: " + marks);
        System.out.println("Grade: " + calculateGrade(marks));
    }

    @Override
    public String calculateGrade(double marks) {
        if (marks >= 90) return "A";
        else if (marks >= 75) return "B";
        else if (marks >= 60) return "C";
        else if (marks >= 45) return "D";
        else return "F";
    }

	public static void add(Student student) {
		// TODO Auto-generated method stub
		
	}
}
