
public interface Grading {
    String calculateGrade(double marks);
}
